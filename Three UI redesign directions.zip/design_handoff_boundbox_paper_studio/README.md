# Handoff: BoundBox — "Paper Studio" redesign (option 1c)

## Overview
BoundBox is a single-screen tool for describing layouts to an AI *visually*: instead of writing prose, the user drags out labeled boxes on a canvas, annotates them, and exports the layout as JSON for a model to build against. It has two modes — **Sketch** (boxes on a blank canvas) and **Iterate** (edits over an AI-authored wireframe background).

"Paper Studio" is a fresh redesign of the existing app that leans into the sketching metaphor: warm paper surfaces, a serif display face, and a soft terracotta accent. It keeps the app's original three-region layout (header · center canvas · right sidebar) but restyles it and adds two new features: an **Insert element** form-component palette and an **Ask the AI** composer docked at the bottom of the sidebar.

## About the design files
The file in this bundle (`1c-paper-studio.dc.html`) is a **design reference created in HTML** — a static prototype showing the intended look, layout, and component styling. It is **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Svelte, etc.) using its established component patterns, state model, and libraries. BoundBox today is a dependency-free, single-file vanilla-JS app (`src/*.mjs` bundled into one HTML file); if you are implementing inside that codebase, keep it dependency-free and DOM-driven from the headless editor state (see the app's `CLAUDE.md`). If there is no target environment yet, pick the most appropriate framework for the project and implement there.

The prototype is **static**: the boxes, sidebar values, and controls are visual mockups with no interactivity. Wire up real behavior from the "Interactions & Behavior" and "State Management" sections below.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, radii, and shadows are final and exact — reproduce them precisely. The two new features (Insert element palette, Ask the AI composer) are design proposals; their *visual* spec is final, but confirm the intended *behavior* with the product owner before building (see notes inline).

## Screens / Views

### Main workspace (only screen)
- **Purpose:** The user draws and labels boxes on the canvas, edits the selected box in the sidebar, optionally inserts pre-made form elements, and exports the layout for an AI (Save for AI / Copy JSON) or asks the AI directly via the composer.
- **Overall frame:** 1240 × 780 px card, `background #f0e9d8`, `border 1px solid #ddd0b3`, `border-radius 14px`, `box-shadow 0 1px 3px rgba(80,60,20,.12), 0 18px 50px rgba(80,60,20,.14)`. Vertical flex: header (fixed) + body (flex:1). In production this frame is the full app viewport — the fixed size is only for the mock.
- **Body layout:** horizontal flex — canvas region `flex:1` (fills remaining space) + right sidebar `flex:0 0 300px`. `min-height:0` on the body so the sidebar can scroll.

#### 1. Header (top bar)
- Height 56px, `background #faf6ea`, `border-bottom 1.5px solid #e4d9bf`, `padding 0 20px`, horizontal flex, `gap 16px`, items vertically centered.
- **Wordmark:** "BoundBox", Fraunces 600, 22px, `letter-spacing -0.01em`, color `#2a2418`.
- **Mode switch (segmented pill):** container `background #efe6d0`, `border 1.5px solid #e0d4b6`, `border-radius 999px`, `padding 3px`, `gap 2px`. Active segment ("Sketch"): `background #2a2418`, text `#f0e9d8`, 600, 12.5px, `padding 4px 15px`, `border-radius 999px`. Inactive ("Iterate"): text `#8a7d5f`, 12.5px, same padding. Only one active at a time; switching changes the whole app mode (Sketch ⇄ Iterate).
- **Spacer** (`flex:1`) pushes the rest right.
- **Save status:** italic 11.5px, `#8a7d5f` — e.g. "untitled sketch · unsaved". Reflects real dirty state.
- **Copy JSON button:** `padding 7px 13px`, `border 1.5px solid #cdbf9c`, `border-radius 999px`, `background #faf6ea`, 12.5px.
- **Save for AI button (primary):** `padding 7px 17px`, `border-radius 999px`, `background #b8703a`, text `#fff` 600 12.5px, `box-shadow 0 2px 8px rgba(184,112,58,.3)`.

#### 2. Canvas region (center)
- `flex:1`, `position:relative`, `overflow:hidden`, `background #e7ddc6`.
- **Grid texture:** two crossed linear-gradients, `rgba(140,120,80,.09) 1px` lines, `background-size 26px 26px` (26px grid).
- **Floating tool dock (left):** absolutely positioned, `left 16px`, vertically centered (`top 50%; translateY(-50%)`). `background #faf6ea`, `border 1.5px solid #e0d4b6`, `border-radius 12px`, `padding 6px`, `box-shadow 0 8px 30px rgba(80,60,20,.16)`, column flex `gap 4px`, `z-index 5`. Four 36×36px tool buttons, `border-radius 9px`:
  - **Draw (active):** `background #b8703a`, contains a 14×14 white-bordered square (the box tool).
  - **Select:** transparent, `color #8a7d5f`, a small triangle/cursor glyph.
  - **Pan/frame:** transparent, `color #8a7d5f`, 14×14 dashed square.
  - Divider: 20px × 1px line, `background #e4d9bf`.
  - **Text tool:** "T", Inter 600 15px, `color #8a7d5f`.
- **Sketch sheet (the drawing surface):** absolutely centered (`left 50%; top 52%; translate(-50%,-50%)`), 600 × 540px, `background #fffdf7`, `border-radius 2px`, `box-shadow 0 2px 4px rgba(80,60,20,.1), 0 24px 56px rgba(80,60,20,.16)`. In production this is the actual normalized canvas (default 1024×768, exported on a 0–1000 grid); the 600×540 is just the mock size.
- **Boxes on the sheet** (each absolutely positioned; label chip pinned to its top-left):
  - `hero` — object box. `left 36 top 32 w 528 h 160`. Fill `rgba(184,112,58,.06)`, `border 2px solid #b8703a`. Chip: Inter 600 11px, `background #b8703a`, `#fff`, `padding 2px 8px`, `border-radius 999px`, at `left 6 top 6`. Also carries a description hint bottom-left: Fraunces italic 12px, `#a08a5f`, "Big product shot + headline".
  - `tagline` — **text-type** box. `left 36 top 206 w 250 h 130`. Fill `rgba(70,110,90,.07)`, `border 2px solid #3f7a5c` (green = text type). Chip `background #3f7a5c`.
  - `signup` — object box. `left 300 top 206 w 264 h 130`. Same terracotta styling as `hero`.
  - **Empty/add affordance:** `left 36 top 350 w 528 h 158`. `border 2px dashed #cdbf9c`, fill `rgba(184,112,58,.06)`, centered Fraunces italic 13px `#b0a077` text "drag to add another box…".

#### 3. Sidebar (right)
- `flex:0 0 300px`, `background #faf6ea`, `border-left 1.5px solid #e4d9bf`, column flex. Two parts: a scrollable body (`flex:1; overflow:auto; padding 16px 18px`) and a fixed composer footer.

**3a. Selected box editor** (top of scroll body)
- **Title:** the box label — Fraunces 600 20px `#2a2418` ("hero").
- **Field label style (reused throughout):** `display:block`, `color #8a7d5f`, 11px, `margin 6px 0 4px` (or `12px 0 4px` between groups).
- **Input style (reused):** `border 1.5px solid #e0d4b6`, `background #fffdf7`, `border-radius 9px`, `padding 9px 11px` (text areas) / `7px 10px` (numeric). Text color `#3d3526`.
- **"Describe what goes here":** multiline input, `min-height 52px`, `line-height 1.45`.
- **Type toggle:** two equal buttons in a `gap 6px` flex row. Selected ("Object"): `background #2a2418`, `#f0e9d8`, 600, `border-radius 9px`, `padding 8px`. Unselected ("Text"): `border 1.5px solid #e0d4b6`, `color #8a7d5f`. (Text type turns the box border/chip green `#3f7a5c`.)
- **Position & size:** 2×2 grid (`grid-template-columns 1fr 1fr; gap 7px`). Four numeric inputs (X, Y, W, H), values shown in JetBrains Mono 500 12px: `40 / 120 / 880 / 320`.

**3b. Insert element palette** — NEW FEATURE
- **Section header:** Fraunces 600 13px `#2a2418` "Insert element" + a **NEW** badge (see badge token) + right-aligned italic hint "drag onto canvas" (`#a08a5f`, 11px). `margin 24px 0 10px`.
- **Category tabs (segmented):** `background #efe6d0`, `border 1.5px solid #e0d4b6`, `border-radius 8px`, `padding 3px`, three equal tabs. Active ("Fields"): `background #fffdf7`, `box-shadow 0 1px 2px rgba(80,60,20,.12)`, 600 11.5px `#2a2418`. Inactive ("Choice", "Misc"): `#8a7d5f`. Switching tabs swaps the element set below.
- **Element cards** (column flex `gap 8px`; each card `border 1.5px solid #e0d4b6`, `background #fffdf7`, `border-radius 9px`, `padding 9px 10px`, with a 10.5px `#8a7d5f` caption):
  - **Text field:** caption "Text field" + a sub-input `border 1.5px solid #e0d4b6`, `background #f4ecda`, `border-radius 6px`, `padding 5px 8px`, placeholder text `#b0a077` 11.5px.
  - **Checkboxes:** two rows, 12px `#3d3526`. Checked box: 15×15, `border-radius 4px`, `background #b8703a`, white ✓ (10px, 700). Unchecked: 15×15, `border-radius 4px`, `border 1.5px solid #cdbf9c`, `background #f4ecda`.
  - **Radio buttons:** two rows. Selected: 15×15 circle, `border 1.5px solid #b8703a`, inner 7×7 dot `#b8703a`. Unselected: 15×15 circle, `border 1.5px solid #cdbf9c`, `background #f4ecda`.
  - **Slider:** caption row with right-aligned mono value `#b8703a` ("64"). Track: 5px tall, `background #efe6d0`, `border-radius 999px`; fill 60% wide `#b8703a`; thumb 15×15 circle `background #fffdf7`, `border 1.5px solid #b8703a`, `box-shadow 0 1px 3px rgba(80,60,20,.2)`.
  - **Toggle + Select row:** two equal cards (`gap 8px`).
    - Toggle (on): 34×19 pill, `background #b8703a`, 15×15 white knob pinned right (`right 2 top 2`).
    - Select: sub-box `border 1.5px solid #e0d4b6`, `background #f4ecda`, `border-radius 6px`, `padding 4px 7px`, "Option A" + a `▾` caret `#8a7d5f`.

**3c. Ask the AI composer** (fixed footer) — NEW FEATURE
- `border-top 1.5px solid #e4d9bf`, `padding 14px 18px`, `background #f4ecda`.
- **Header:** Fraunces 600 13px `#2a2418` "Ask the AI" + NEW badge.
- **Prompt box:** `background #fffdf7`, `border 1.5px solid #e0d4b6`, `border-radius 11px`, `padding 10px 12px`, placeholder italic `#8a7d5f`, `line-height 1.4`.
- **Action row:** left caption `#8a7d5f` 11px ("6 elements attached" — count of boxes currently on the canvas). Right primary "Send ↑" button: `padding 7px 16px`, `border-radius 999px`, `background #b8703a`, `#fff` 600 12.5px.

## Interactions & Behavior
Existing BoundBox behaviors to preserve (see the app's `src/editor.mjs` / `app.mjs`):
- **Draw:** drag on the canvas creates a labeled box; on release the description field focuses. Boxes clamp to the canvas bounds.
- **Select / move / resize:** click selects (shows selection outline + 8 handles); drag moves; handles resize. Sidebar Position & size inputs edit the same rect and must reflect clamped/rejected values.
- **Type:** Object vs Text. Text-type boxes render green (`#3f7a5c`); object boxes terracotta (`#b8703a`).
- **Undo/redo:** Ctrl/Cmd+Z / Shift+Z (or Ctrl+Y), bounded 100-snapshot overlay-only stack. Delete/Backspace deletes selection. Escape in a field cancels the edit (restores from state); Escape otherwise clears selection.
- **Mode switch:** Sketch ⇄ Iterate. In Iterate, a wireframe SVG renders as a read-only background, every bindable element becomes a selectable bound box (purple in the original), canvas size follows the wireframe (size inputs disabled), and edits diff into a packet. (This redesign shows Sketch mode; carry the Iterate treatment over with the same paper palette — bound = terracotta or a distinct paper-friendly accent; confirm.)
- **Export:** "Save for AI" writes `boxes.json` (Sketch) / `packet.json` (Iterate) to the exchange folder via the launcher; "Copy JSON" copies the same payload to clipboard.
- **Dirty/save state:** header status reflects unsaved changes; Ctrl/Cmd+S saves the project; warn on unload when dirty.

New features to define behavior for (confirm with product owner):
- **Insert element palette:** dragging a card onto the canvas should create a box pre-labeled/typed for that control (e.g. "checkbox", "slider") — decide whether these are just labeled boxes (consistent with the JSON contract) or a richer element type. Tabs (Fields / Choice / Misc) filter the palette.
- **Ask the AI composer:** submitting should package the current layout (same payload as Save for AI) plus the prompt text and hand it to the model. "N elements attached" tracks the live box count.

### Transitions
No specific animations are specified. Use the codebase's existing conventions for hover/active states and any button/segment transitions. Suggested: subtle background/opacity change on hover for buttons and palette cards; the selected segment/tab moves instantly.

## State Management
Mirror the existing headless editor model (`createEditor()` in `src/editor.mjs`), which owns:
- `mode` (`sketch` | `iterate`), `canvas {w,h}`, `boxes[]` (each `{id, label, description/note, type, rect{x,y,w,h}, origin, binding?, deleted?}`), `selectedId`, `interaction` (pointer state machine: idle/drawing/dragging/resizing + preview rect), and `context {description, style, background}`.
- Undo/redo snapshot stacks (overlay-only, excludes wireframe state).
- Derived export payloads via `toPayload()` (sketch `boxes.json` / iterate `packet.json`), computed by diffing overlay state against wireframe bindings — not an event log.

New state for the added features:
- Insert palette: active category tab; a "pending insert" when a card is dragged.
- Composer: prompt text; attached-element count derived from `boxes.length`.

Keep the editor DOM-free and unit-testable; the view layer renders from state on every change (the original app re-renders the SVG overlay + sidebar per event).

## Design Tokens

### Colors
| Role | Hex |
|---|---|
| App frame / page bg (warm paper) | `#f0e9d8` |
| Frame border | `#ddd0b3` |
| Panel / header / sidebar surface | `#faf6ea` |
| Sketch sheet / input surface | `#fffdf7` |
| Recessed input / sub-control fill | `#f4ecda` |
| Segmented-control track | `#efe6d0` |
| Canvas background | `#e7ddc6` |
| Canvas grid lines | `rgba(140,120,80,.09)` |
| Border (standard) | `#e0d4b6` |
| Border (section dividers) | `#e4d9bf` |
| Border (buttons / dashed) | `#cdbf9c` |
| Primary accent (terracotta) | `#b8703a` |
| Accent hover (suggested) | `#9a5c2c` |
| Ink / display text | `#2a2418` |
| Body text | `#3d3526` |
| Muted text / labels | `#8a7d5f` |
| Faint text / hints | `#a08a5f` / `#b0a077` |
| Text-type box (green) | `#3f7a5c` |
| Object-box fill | `rgba(184,112,58,.06)` |
| Text-box fill | `rgba(70,110,90,.07)` |
| Dark toggle/segment active text | `#f0e9d8` |

### Typography
- **Display / headings:** Fraunces (serif), weights 500/600. Wordmark 22px, section titles 13px, box title 20px. Italic Fraunces used for canvas hints.
- **UI / body:** Inter, 400/500/600/700. Body 13px, labels 11px, small captions 10.5–11.5px, buttons 12.5px.
- **Numeric / code:** JetBrains Mono, 400/500/600 — position/size inputs, slider value.

### Spacing
- Header height 56px; header padding `0 20px`, gap 16px.
- Sidebar width 300px; sidebar body padding `16px 18px`; composer footer padding `14px 18px`.
- Tool dock offset `left 16px`; dock padding 6px, button gap 4px.
- Common control gaps: 6–8px; grid gap 7px; section top margin 22–24px.

### Border radius
- Frame 14px · panels/cards 9–12px · inputs 6–9px · pills/buttons/segments 999px · boxes on sheet 2–3px · small glyph squares 2–4px.

### Shadows
- Frame: `0 1px 3px rgba(80,60,20,.12), 0 18px 50px rgba(80,60,20,.14)`
- Sketch sheet: `0 2px 4px rgba(80,60,20,.1), 0 24px 56px rgba(80,60,20,.16)`
- Tool dock: `0 8px 30px rgba(80,60,20,.16)`
- Primary button: `0 2px 8px rgba(184,112,58,.3)`
- Slider thumb: `0 1px 3px rgba(80,60,20,.2)`
- Active segment/tab: `0 1px 2px rgba(80,60,20,.12)`

### NEW badge
- Inline flex, JetBrains Mono 700 8.5px, `letter-spacing .06em`, `padding 2px 5px`, `border-radius 3px`, `background #b8703a`, text `#fff`.

## Assets
- **Fonts:** Fraunces, Inter, JetBrains Mono — loaded from Google Fonts in the prototype; use the codebase's font-loading approach (self-host or existing pipeline) in production.
- **Icons:** all tool-dock and control glyphs are drawn with plain CSS/HTML (borders, triangles, characters) — no icon assets. Replace with the codebase's icon set if it has one; keep them monochrome `#8a7d5f` (inactive) / white on `#b8703a` (active).
- No images or external media are used.

## Files
- `1c-paper-studio.dc.html` — the high-fidelity design reference (this bundle). Open in a browser to inspect exact rendering; view source for precise inline styles.
- For the current app's real behavior/architecture, reference the source repo: `src/editor.mjs` (headless controller + state machine), `src/app.mjs` (DOM/render layer), `src/geometry.mjs`, `src/export.mjs`, `src/packet.mjs`, `src/wireframe.mjs`, and `CLAUDE.md` (architecture notes).
